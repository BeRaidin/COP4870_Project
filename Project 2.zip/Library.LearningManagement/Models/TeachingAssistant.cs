﻿namespace Library.LearningManagement.Models
{
    public class TeachingAssistant : Person
    {
    }
}
