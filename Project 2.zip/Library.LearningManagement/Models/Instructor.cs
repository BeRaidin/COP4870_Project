﻿namespace Library.LearningManagement.Models
{
    public class Instructor : Person
    {
    }
}
